//
//  AppDelegate.h
//  Webservice Demo
//
//  Created by Parth Patel on 10/04/16.
//  Copyright (c) 2016 Parth Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

