//
//  main.m
//  Webservice Demo
//
//  Created by Parth Patel on 10/04/16.
//  Copyright (c) 2016 Parth Patel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
