//
//  ViewController.m
//  Webservice Demo
//
//  Created by Parth Patel on 10/04/16.
//  Copyright (c) 2016 Parth Patel. All rights reserved.
//


//https://spring.io/guides/gs/consuming-rest-ios/

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *arrCategory;
    UIActivityIndicatorView *loader;
    CGSize screenSize;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    loader = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    CGSize size = [UIScreen mainScreen].bounds.size;
    loader.hidesWhenStopped = true;
    loader.color = [UIColor redColor];
    loader.frame = CGRectMake((size.width / 2) - 25,(size.height / 2) - 25,50,50);
    
    screenSize = [UIScreen mainScreen].bounds.size;
    
    arrCategory = [[NSArray alloc] init];
    _tblCategory.rowHeight = 70;
    _tblCategory.dataSource = self;
    
    [self fetchGreeting];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrCategory.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellId = [NSString stringWithFormat:@"TableCell%ld",(long)indexPath.row];
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellId];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellId];
        UIImageView *backImg = [[UIImageView alloc] initWithFrame:CGRectMake(10,5,screenSize.width - 20,60)];
        backImg.tag = 101;
        [cell.contentView addSubview:backImg];
        
        
        cell.textLabel.backgroundColor = [UIColor clearColor];
        
    }
   // cell.backgroundColor = (indexPath.row % 2 == 0) ? [UIColor grayColor] : [UIColor cyanColor];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    cell.textLabel.textColor = [UIColor whiteColor];
    NSDictionary *dict = [arrCategory objectAtIndex:indexPath.row];
    [self getImageFromString:[dict valueForKey:@"category_image"] setImage:cell];
    cell.textLabel.text = [dict valueForKey:@"category_name"];
    return cell;
    
}
-(void)getImageFromString:(NSString*)strurl setImage:(UITableViewCell *)cell
{
    UIActivityIndicatorView *imageLoder = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    imageLoder.hidesWhenStopped = true;
    imageLoder.color = [UIColor redColor];
    imageLoder.frame = CGRectMake((screenSize.width / 2) - 25,10,50,50);
    [imageLoder startAnimating];
    
    UIImageView *backImage = (UIImageView*)[cell.contentView viewWithTag:101];
    [backImage addSubview:imageLoder];
    
    NSURL *url = [NSURL URLWithString:strurl];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:[NSOperationQueue mainQueue]
                           completionHandler:^(NSURLResponse *response,
                                               NSData *data, NSError *connectionError)
     {
        // NSLog(@"%@",data);
         [imageLoder stopAnimating];
         if (data.length > 0 && connectionError == nil)
         {
             backImage.image = [UIImage imageWithData:data];
         }
     }];

}
- (IBAction)fetchGreeting;
{
    
    [loader startAnimating];
    [self.view addSubview:loader];
    NSURL *url = [NSURL URLWithString:@"https://tipple.com.au/webservice_v2/category?store_id=2&token=wdq"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:[NSOperationQueue mainQueue]
                           completionHandler:^(NSURLResponse *response,
                                               NSData *data, NSError *connectionError)
     {
         if (data.length > 0 && connectionError == nil)
         {
             NSDictionary *greeting = [NSJSONSerialization JSONObjectWithData:data
                                                                      options:0
                                                                        error:NULL];
             [loader stopAnimating];
             arrCategory = [greeting valueForKey:@"data"];

             [_tblCategory reloadData];
             
             
            
         }
     }];
}


@end
