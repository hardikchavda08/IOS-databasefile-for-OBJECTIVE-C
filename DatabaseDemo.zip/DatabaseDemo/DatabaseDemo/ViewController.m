//
//  ViewController.m
//  DatabaseDemo
//
//  Created by Parth Patel on 17/04/16.
//  Copyright (c) 2016 Parth Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    
    __weak IBOutlet UITextField *txt_city;
    __weak IBOutlet UITextField *txt_mob;
    __weak IBOutlet UITextField *txt_name;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)insert:(UIButton *)sender
{
    
//    NSString *query = @"insert into tbl('Name','city','mob_no') values('hardik','Ahmedabad','8732999701')";
    

    if ([[Database shareDatabase]createNewTable:@" CREATE TABLE IF NOT EXISTS student_info (Name TEXT,City TEXT ,Number INTEGER)"])
    {
    
        NSString *query = [NSString stringWithFormat:@"insert into student_info ('Name','City','Number') values ('%@','%@',%@)",txt_name.text,txt_city.text,txt_mob.text];
        [[Database shareDatabase]Insert:query];
    }
    
      NSString *queryz = [NSString stringWithFormat:@"select * from student_info"];
    NSMutableArray *arr = [[Database shareDatabase]SelectAllFromTable:queryz];
    NSLog(@"%@",arr);
    
}

@end
