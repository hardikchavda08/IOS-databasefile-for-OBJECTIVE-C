//
//  ViewController.swift
//  ParthSqliteDemo
//
//  Created by Parth Patel on 24/07/16.
//  Copyright (c) 2016 Parth Patel. All rights reserved.
//

import UIKit


class HomeCellView: UITableViewCell
{

    @IBOutlet weak var lbl_Email: UILabel!
    
    @IBOutlet weak var btnEdit: UIButton!
    
    @IBOutlet weak var btnDelete: UIButton!
}


class ViewController: UIViewController
{

    
    
    @IBOutlet weak var homeTableview: UITableView!
    var databasePath:String!
    var arrEmpData:NSMutableArray!
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        
        
        arrEmpData = NSMutableArray()
        
        //Get Database Tath
        let filemgr = NSFileManager.defaultManager()
        let dirPaths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)
        let docsDir = dirPaths[0] as String
        databasePath = docsDir.stringByAppendingPathComponent("ParthDatabase.sqlite")
        
        if !filemgr.fileExistsAtPath(databasePath as String)
        {
            
            let contactDB = FMDatabase(path: databasePath as String)
            
            if contactDB == nil
            {
                println("Error: \(contactDB.lastErrorMessage())")
            }
            
            if contactDB.open() {
                
                //let sql_stmt = "CREATE TABLE EmpInfo (empID INTEGER PRIMARY KEY AUTOINCREMENT, empName TEXT)"
                //CREATE TABLE "ParthInfo" ("Name" TEXT, "Phone" TEXT, "Comment" TEXT, "Email" TEXT PRIMARY KEY  NOT NULL )
                let sql_stmt = "CREATE TABLE ParthInfo (Name TEXT, Phone TEXT, Comment TEXT, Email TEXT PRIMARY KEY  NOT NULL)"
                
                
                if !contactDB.executeStatements(sql_stmt) {
                    println("Error: \(contactDB.lastErrorMessage())")
                }
                contactDB.close()
            } else {
                println("Error: \(contactDB.lastErrorMessage())")
            }
        }
        
    }
    
    
    override func viewWillAppear(animated: Bool)
    {
        
        super.viewWillAppear(true)
        listAllData()
        
    }
    
    
    

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func listAllData()
    {
        arrEmpData.removeAllObjects()
        
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open() {
            let querySQL = "SELECT * FROM ParthInfo"
            
            if let results:FMResultSet? = contactDB.executeQuery(querySQL,withArgumentsInArray: nil)
            {
                while results?.next() == true
                {
                    let dictRecord = results?.resultDictionary()
                    arrEmpData.insertObject(dictRecord!, atIndex: arrEmpData.count)
                   
                    print("\nRESULT : \(results?.resultDictionary())")
                }
                
                homeTableview.reloadData()
            }
            else
            {
                print("Record not found")
            }
            contactDB.close()
        }
        else
        {
            println("Error: \(contactDB.lastErrorMessage())")
        }
    }
    
    func saveData(tagNo:NSInteger)
    {
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open()
        {
            let insertSQL = "INSERT INTO EmpInfo (empName) VALUES ('Ram')"
            
            //        let insertSQL = "INSERT INTO CONTACTS (name, address, phone) VALUES ('Pankaj', 'Address', '1234567')"
            
            let result = contactDB.executeUpdate(insertSQL,
                withArgumentsInArray: nil)
            
            if !result
            {
                println("Error: \(contactDB.lastErrorMessage())")
            }
            else
            {
                print("Successfully Record Added.")
            }
        }
        else
        {
            println("Error: \(contactDB.lastErrorMessage())")
        }
        contactDB.close()
    }

    
    
    @IBAction func btn_Edit_Clicked(sender: UIButton)
    {
        let updateView = self.storyboard?.instantiateViewControllerWithIdentifier("UpdateDataScreen") as UpdateDataScreen
        updateView.strEmail = arrEmpData[sender.tag]["Email"] as? String
        updateView.dictRecord = arrEmpData[sender.tag] as NSDictionary
        self.navigationController?.pushViewController(updateView, animated: true)
    }
    
    
    @IBAction func btn_Delete_Clicked(sender: UIButton)
    {
        let contactDB = FMDatabase(path: databasePath as String)
        
        let strDelete = arrEmpData[sender.tag]["Email"] as? String
        
        
        if contactDB.open()
        {
            let deleteSQL = "DELETE FROM ParthInfo WHERE Email='\(strDelete!)'"
            
            let result = contactDB.executeUpdate(deleteSQL, withArgumentsInArray: nil)
            if !result
            {
                println("Error: \(contactDB.lastErrorMessage())")
            }
            else
            {
                print("Deleted Record.")
                listAllData()
            }
        }
        else
        {
            println("Error: \(contactDB.lastErrorMessage())")
        }
        contactDB.close()
        
    }


    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrEmpData.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        var cell = tableView.dequeueReusableCellWithIdentifier("cellhome") as HomeCellView
        
        cell.lbl_Email.text = arrEmpData[indexPath.row]["Email"] as? String
        cell.btnDelete.tag = indexPath.row
        cell.btnEdit.tag = indexPath.row
        
        cell.btnEdit.addTarget(self, action: Selector("btn_Edit_Clicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        
        cell.btnDelete.addTarget(self, action: Selector("btn_Delete_Clicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        
        return cell
    }


}

