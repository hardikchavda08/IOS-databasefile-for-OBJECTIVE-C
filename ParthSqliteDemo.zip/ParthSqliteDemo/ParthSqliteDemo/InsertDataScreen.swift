//
//  InsertDataScreen.swift
//  ParthSqliteDemo
//
//  Created by Parth Patel on 24/07/16.
//  Copyright (c) 2016 Parth Patel. All rights reserved.
//

import UIKit

class InsertDataScreen: UIViewController {

    
    @IBOutlet weak var txtfld_Insert_Name: UITextField!
    @IBOutlet weak var txtfld_Insert_Phone: UITextField!
    @IBOutlet weak var txtfld_Insert_Email: UITextField!
    @IBOutlet weak var txtfld_Insert_Comment: UITextField!
    
    var databasePath:String!
    var arrEmpData:NSMutableArray!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        
        arrEmpData = NSMutableArray()
        
        //Get Database Tath
        let filemgr = NSFileManager.defaultManager()
        let dirPaths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory,.UserDomainMask, true)
        let docsDir = dirPaths[0] as String
        databasePath = docsDir.stringByAppendingPathComponent("ParthDatabase.sqlite")
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnSaveClicked(sender: AnyObject)
    {
        
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open()
        {
            let insertSQL = "INSERT INTO ParthInfo (Name, Phone, Comment, Email) VALUES ('\(txtfld_Insert_Name.text)','\(txtfld_Insert_Phone.text)','\(txtfld_Insert_Comment.text)','\(txtfld_Insert_Email.text)')"
            
            //        let insertSQL = "INSERT INTO CONTACTS (name, address, phone) VALUES ('Pankaj', 'Address', '1234567')"
            
            let result = contactDB.executeUpdate(insertSQL,
                withArgumentsInArray: nil)
            
            if !result
            {
                println("Error: \(contactDB.lastErrorMessage())")
            }
            else
            {
                print("Successfully Record Added.")
                self.navigationController?.popViewControllerAnimated(true)
            }
        }
        else
        {
            println("Error: \(contactDB.lastErrorMessage())")
        }
        contactDB.close()
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
